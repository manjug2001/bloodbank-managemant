<?php
include_once('Search Person.php');

if(isset($_POST['p_id']) && isset($_POST['p_name']) && isset($_POST['p_gender']) && isset($_POST['p_phone']) && isset($_POST['p_dob']) && isset($_POST['p_blood_group']) && isset($_POST['p_address']) && isset($_POST['p_med_issues'])){
    $pid = $_POST['p_id'];
    $p_name = $_POST['p_name'];
    $p_gender = $_POST['p_gender'];
    $p_phone = $_POST['p_phone'];
    $p_dob = $_POST['p_dob'];
    $p_blood_group = $_POST['p_blood_group'];
    $p_address = $_POST['p_address'];
    $p_med_issues = $_POST['p_med_issues'];

    $con = mysqli_connect("127.0.0.1", "root", "oraclej", "blood_bank");

    // Prepare the statement
    $stmt = mysqli_prepare($con, "UPDATE Person SET p_name=?, p_gender=?, p_phone=?, p_dob=?, p_blood_group=?, p_address=?, p_med_issues=? WHERE p_id=?");

    // Bind the parameters
    mysqli_stmt_bind_param($stmt, "sssssssi", $p_name, $p_gender, $p_phone, $p_dob, $p_blood_group, $p_address, $p_med_issues, $pid);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Check for errors
    if(mysqli_stmt_error($stmt)){
        echo "Error: " . mysqli_stmt_error($stmt);
    } else{
        header("Location: person_info.php?p_id=$pid");
    }

    // Close the statement and the connection
    mysqli_stmt_close($stmt);
    mysqli_close($con);
}
?>