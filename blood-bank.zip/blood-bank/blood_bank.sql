-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2024 at 02:46 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `donation`
--

CREATE TABLE `donation` (
  `p_id` int(10) NOT NULL,
  `d_date` date NOT NULL,
  `d_time` time NOT NULL,
  `d_quantity` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donation`
--

INSERT INTO `donation` (`p_id`, `d_date`, `d_time`, `d_quantity`) VALUES
(1, '2024-02-14', '02:25:00', 2),
(2, '2024-02-14', '02:26:00', 4),
(3, '2024-02-14', '02:27:00', 3),
(4, '2024-02-14', '02:27:00', 1),
(5, '2024-02-14', '02:28:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `p_id` int(10) NOT NULL,
  `p_name` varchar(25) NOT NULL,
  `p_phone` char(10) NOT NULL,
  `p_dob` date NOT NULL,
  `p_address` varchar(100) DEFAULT NULL,
  `p_gender` char(1) NOT NULL,
  `p_blood_group` varchar(3) NOT NULL,
  `p_med_issues` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`p_id`, `p_name`, `p_phone`, `p_dob`, `p_address`, `p_gender`, `p_blood_group`, `p_med_issues`) VALUES
(1, 'DENNIS', '9856321740', '2000-01-14', 'ASHOK NAGAR ,BANGLORE', 'm', 'A+', 'DENGUE'),
(2, 'ANUSH', '9865231470', '1998-10-20', 'VINOBANAGARA,SHIVAMOGGA', 'm', 'B-', 'CANCER'),
(3, 'KARAN', '9874568963', '1995-02-07', 'SHIVAJI NAGAR,MYSORE', 'm', 'O+', 'HIV'),
(4, 'POOJA', '9856321740', '1998-02-25', 'RAJAJI NAGAR ,TUMKUR', 'f', 'O+', 'HEART DISORDER'),
(5, 'JAYA', '9632147850', '2010-06-05', 'KUVEMPU NAGAR ,BIDAR', 'f', 'A-', 'JAUNDICE');

-- --------------------------------------------------------

--
-- Table structure for table `receive`
--

CREATE TABLE `receive` (
  `p_id` int(10) NOT NULL,
  `r_date` date NOT NULL,
  `r_time` time NOT NULL,
  `r_quantity` int(1) NOT NULL,
  `r_hospital` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receive`
--

INSERT INTO `receive` (`p_id`, `r_date`, `r_time`, `r_quantity`, `r_hospital`) VALUES
(1, '2024-02-14', '02:25:00', 1, 'NANJAPPA'),
(2, '2024-02-14', '02:27:00', 3, 'NIRMALA'),
(3, '2024-02-14', '02:27:00', 2, 'KAMALA'),
(4, '2024-02-14', '02:27:00', 1, 'SARJI'),
(5, '2024-02-14', '02:28:00', 3, 'APOLLO');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `s_blood_group` varchar(3) NOT NULL,
  `s_quantity` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`s_blood_group`, `s_quantity`) VALUES
('A+', 1),
('A-', 0),
('AB+', 0),
('AB-', 0),
('B+', 0),
('B-', 1),
('O+', 1),
('O-', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(10) NOT NULL,
  `password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('mala', 'mala1234'),
('pranathi', 'pran1234'),
('SuperAdmin', '12345678'),
('test_user', 'qwertyuiop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donation`
--
ALTER TABLE `donation`
  ADD PRIMARY KEY (`p_id`,`d_date`,`d_time`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `receive`
--
ALTER TABLE `receive`
  ADD PRIMARY KEY (`p_id`,`r_date`,`r_time`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`s_blood_group`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donation`
--
ALTER TABLE `donation`
  ADD CONSTRAINT `Donation_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `person` (`p_id`);

--
-- Constraints for table `receive`
--
ALTER TABLE `receive`
  ADD CONSTRAINT `Receive_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `person` (`p_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
