<?php
session_start();
$_SESSION["tab"] = "Search Person";

if($_SESSION["login"] != 1)
    echo '<h2 txtcolor="red">Authentication Error!!!</h2>';
else{
    include_once('header.php');

    $pid = $_POST['pid'];

    $con = mysqli_connect("127.0.0.1", "root", "oraclej", "blood_bank");
    $sql = "DELETE FROM Person WHERE p_id='$pid'";

    if(mysqli_query($con, $sql)){
        header("Location: searchperson.php");
    } else{
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }

    mysqli_close($con);
}
?>