<?php
session_start();
$_SESSION["tab"] = "Home";

if($_SESSION["login"] != 1)
	echo '<h2 txtcolor="red">Authentication Error!!!</h2>';
else{
	include_once('header.php');

		###########contents of div goes here###########
	echo "
	<h2>
	Abstract
	</h2>
	<br>
	<p>
	Despite the immense technological advancement, blood bank systems are either manual or valuable data Consequently, one of the major issues in blood bank systems, as talked about in many research papers and articles, is the lack of data security. People always doubt whether their personal information and medical records are safely stored and secured. Therefore, our project aims to develop an online blood donation system applying the concepts of database security and encryption. easily retrievable.
	</p>
	<p>
	The following is what our project aims to:<br>
	Admin/User has to login first.Any person who is willing to donate/receive blood will have to register by giving all his personal details. Admin/User has to register the given details . The admin/user will be able to view all the details and records of all earlier donation/receive as well as the stock of blood in the blood bank. All this is related to the blood bank system. Apart from this, we will be using concepts of database encryption to make sure that the users' information is kept secure and confidential. This will help us keep their donation records protected from any threats from individuals with potentially malicious intentions, or unforeseen hazards to the security of the data.
	</p>
	<h2>
	Objectives of the Practice:
    </h2>
	<br>
	<p>
	1. To sensitize the need of donating blood to the needy in time
	<br>
	2. To instil the feeling of helping others to breathe life with their precious donation
	<br>
	3. To motivate all students to take a pledge to donate blood at least once in a year
	<br>
	4. To impart to them the value of blood donation
	<br>
	5. To aware of the scientific information about the blood group</p>
    <h2>
	The Benefits of Donating Blood
	</h2>
	<br>
	<p>
	Donating blood has benefits for your emotional and physical health. According to a report by the Mental Health Foundation, helping others can:
    <br>
		1. reduce stress<br>
		2. improve your emotional well-being<br>
		3. benefit your physical health<br>
		4. help get rid of negative feelings<br>
		5. provide a sense of belonging and reduce isolation<br>
		6. Research has found further evidence of the health benefits that come specifically from donating blood.<br>
	    <br>
		<br>
		
		Free health checkup:<br>
		In order to give blood, you're required to undergo a health screening. A trained staff member performs this checkup. They’ll check your:<br>
		
		1. pulse<br>
		2. blood pressure<br>
		3. body temperature<br>
		4. hemoglobin levels<br>
		<br>
		This free mini-physical can offer excellent insight into your health. It can effectively detect problems that could indicate an underlying medical condition or risk factors for certain diseases.<br>
		<br>
		<br>
		Your blood is also tested for several diseases. These include:<br>
		
		1. hepatitis B<br>
		2. hepatitis C<br>
		3. HIV<br>
		4. West Nile virus<br>
		5. syphilis<br>
		6. Trypanosoma cruzi<br>
		<br>
		<br>
		<h2>
		What to know before you donate</h2><br>
        Here are some important things to know before you donate:<br>

        1. You need to be 17 or older to donate whole blood. Some states allow you to donate at 16 with parental consent.<br>
        2. You have to weigh at least 110 pounds and be in good health to donate.<br>
        3. You need to provide information about medical conditions and any medications you’re taking. These may affect your eligibility to donate blood.<br>
        4. You must wait at least 8 weeks between whole blood donations and 16 weeks between double red cell donations.<br>
        5. Platelet donations can be made every 7 days, up to 24 times per year.<br>
		<br>
		<br>
        The following are some suggestions to help you prepare for donating blood:<br>

        1. Drink an extra 16 ounces of water before your appointment.<br>
        2. Eat a healthy meal that’s low in fat.<br>
        3. Wear a short-sleeved shirt or a shirt with sleeves that are easy to roll up.<br>
		
		</p>";


		##################################################
	include_once('footer.php');
}
?>